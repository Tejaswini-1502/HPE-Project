import React from 'react'

function Footer() {
  return (
    <div className='footer'>
        this is the footer
    </div>
  )
}

export default Footer