import Home from "./HomePage/Home"
function App() {
  return (
    <div className="App">
      {/* routing here */}
      <Home/>
    </div>
  );
}

export default App;
