import React from 'react'

function Navbar() {
  return (
    <div className='navbar'>
        <div className="navbar_content">
          <ul>
            <li><a href="http://localhost:3000/">Genres</a></li>
            <li><a href="http://localhost:3000/">Genres</a></li>
            <li><a href="http://localhost:3000/">Genres</a></li>
            <li><a href="http://localhost:3000/">Genres</a></li>
          </ul>
        </div>
    </div>
  )
}

export default Navbar